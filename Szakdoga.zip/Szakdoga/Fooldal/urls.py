from unicodedata import name
from django.urls import path
from . import views
 
urlpatterns = [
    path('', views.fooldal, name='Fooldal'),
    path('uj-naplo/', views.ujnaplo, name='Ujnaplo'),
    path('naplo/', views.naplofrissit, name='Naplo'),
    path('osszevon/', views.osszevon, name='Osszevon')
]
