from turtle import pen
from django.shortcuts import render, redirect
import Fooldal
import Bejelentkezes
from datetime import date
from Fooldal.models import Olnaplo, FrissNaplo
from Bejelentkezes.models import Felhasznalo

# Create your views here.
def fooldal(request):

    frissnaplok = FrissNaplo.objects.all()


    if request.method == 'POST':

        akttorzsazon = request.POST.get('torzsbutton')
        request.session['akttorzsazon'] = akttorzsazon
        
        return redirect('Naplo')

    olnaplok = Olnaplo.objects.all().filter(tulajdonos = request.session.get('username'))
    
    torzsazonList = []
   
    for o in olnaplok:
        if o.tulajdonos == request.session.get('username'):
            torzsazonList.append(o.torzsazon)
    
    request.session['torzsazonList'] = torzsazonList

    context ={
        'torzsazonList' : torzsazonList,
        'olnaplok' : olnaplok,
        'meret' : len(torzsazonList),
        'tulajdonos' : request.session.get('username')
    }

    return render(request, 'fooldal.html', context)

def ujnaplo(request):

    if request.method == "GET":
        return render(request, 'ujnaplo.html')
    elif request.method == "POST":
        torzsazon = request.POST.get('torzsazon')
        fajta = request.POST.get('fajta')
        indulo = request.POST.get('indulo')
        aktletszam = indulo

        todays_date = date.today()
        kezdoido = str(todays_date.year) + "." +str(todays_date.month) + "." +str(todays_date.day)

        felhasznalok = Felhasznalo.objects.all()
        username = ""
        for felhasznalo in felhasznalok:
            if felhasznalo.email == request.session.get('emailLog'):
                username = felhasznalo.felhnev

        seged = False
        for azon in request.session.get('torzsazonList'):
            print(azon)
            print(torzsazon)
            print('*'*10)
            if str(azon) == torzsazon:
                print('*'*10)
                seged = True
                return render(request, 'ujnaplo.html', {'seged' : seged})
    
        print(seged)
        naplo = Olnaplo(torzsazon = torzsazon, fajta = fajta, induloszam = indulo, tulajdonos = username, kezdet = kezdoido, aktletszam = aktletszam)

        naplo.save()

        return redirect('Ujnaplo')
        
def naplofrissit (request):

    frissnaplok = FrissNaplo.objects.all()
    olnaplok = Olnaplo.objects.all()

    if request.method == 'POST':

        if 'torlesbutton' in request.POST:

            for f in frissnaplok:
                if int(request.session.get('akttorzsazon')) == f.torzsazon and request.session.get('username') == f.tulajdonos:
                    f.delete()

            for o in olnaplok:
                if int(request.session.get('akttorzsazon')) == o.torzsazon and request.session.get('username') == o.tulajdonos:
                    o.delete()

            return redirect('Fooldal')


        if 'visszavonas' in request.POST:

            napok = []
            for f in frissnaplok:
                if int(request.session.get('akttorzsazon')) == f.torzsazon and request.session.get('username') == f.tulajdonos:
                    napok.append(f.nap)

            if len(napok) > 0:
                request.session['elozohim_elhullas'] = FrissNaplo.objects.filter().get(torzsazon = request.session.get('akttorzsazon'), nap = napok[-1]).him_elhullas
                request.session['elozono_elhullas'] = FrissNaplo.objects.filter().get(torzsazon = request.session.get('akttorzsazon'), nap = napok[-1]).no_elhullas
                FrissNaplo.objects.all().filter(torzsazon = request.session.get('akttorzsazon'), nap = napok[-1]).delete()
                return redirect('Naplo')
            else:
                return redirect('Naplo')

            

        if 'hozzaadbutton' in request.POST:

            nap = request.POST.get('nap')
            for o in olnaplok:
                if o.torzsazon == int(request.session['akttorzsazon']) and o.tulajdonos == request.session.get('username') and o.osszevont == True:
                    him_elhullas = request.POST.get('himelhullas')
                    no_elhullas = request.POST.get('noelhullas')
                    elhullas = int(him_elhullas) + int(no_elhullas)
                elif o.torzsazon == int(request.session['akttorzsazon']) and o.tulajdonos == request.session.get('username') and o.osszevont == False:
                    elhullas = request.POST.get('elhullas')
                    him_elhullas = 0
                    no_elhullas = 0
            tojas = request.POST.get('tojas')
            takarmany = request.POST.get('takarmany')
            mozgas = request.POST.get('mozgas')
            megjegyzes = request.POST.get('megjegyzes')

            frissnaplo = FrissNaplo(nap = nap, elhullas = elhullas, tojas = tojas, takarmany = takarmany, egyeb = megjegyzes, torzsazon = request.session.get('akttorzsazon'), tulajdonos = request.session.get('username'), him_elhullas = him_elhullas, no_elhullas = no_elhullas)
            frissnaplo.save()

            

            if (Olnaplo.objects.filter(torzsazon = int(request.session['akttorzsazon']), tulajdonos = request.session.get('username'), osszevont = True).count()) > 0:
                olnaplo = Olnaplo.objects.get(torzsazon = int(request.session['akttorzsazon']), tulajdonos = request.session.get('username'), osszevont = True)
                olnaplo.himivar -= int(him_elhullas)
                olnaplo.noivar -= int(no_elhullas)
                olnaplo.aktletszam = olnaplo.himivar + olnaplo.noivar
                olnaplo.save()

            return redirect('Naplo')
    
    
    elhullas = 0
    for f in frissnaplok:
        if f.torzsazon == int(request.session.get('akttorzsazon')) and f.tulajdonos == request.session.get('username'):
            elhullas += f.elhullas

    aktualis = 0
    for o in olnaplok:
        if o.torzsazon == int(request.session.get('akttorzsazon')) and o.tulajdonos == request.session.get('username'):
            aktualis = o.induloszam - elhullas

    olnaplo = Olnaplo.objects.get(torzsazon = int(request.session.get('akttorzsazon')), tulajdonos = request.session.get('username'))
    olnaplo.aktletszam = aktualis
    # olnaplo.himivar += request.session.get('elozohim_elhullas')
    # olnaplo.noivar += request.session.get('elozono_elhullas')
    olnaplo.save()

    request.session['elozohim_elhullas'] = 0
    request.session['elozono_elhullas'] = 0



    napok = []
    tojas = []
    elhullas = []
    for f in frissnaplok:
        if f.torzsazon == int(request.session.get('akttorzsazon')) and f.tulajdonos == request.session.get('username'):
            napok.append(f.nap)
            tojas.append(f.tojas)
            elhullas.append(f.elhullas)

    context ={
        'aktualis' : aktualis,
        'olnaplok' : olnaplok,
        'akttorzsazon' : int(request.session['akttorzsazon']),
        'frissnaplok' : frissnaplok,
        'tulajdonos' : request.session.get('username'),
        'napok': napok,
        'tojas' : tojas,
        'elhullas' : elhullas,
        'olnaplo' : olnaplo
        }

    return render(request,'naplofrissit.html', context)


def osszevon(request):

    frissNaplok = FrissNaplo.objects.all()
    olnaplok = Olnaplo.objects.all()

    osszevon_torzsazonList = []
    letszam_check_bool = True

    if request.method == 'POST':

        if 'osszevonbutton' in request.POST:

            osszevon_torzsazonList = request.POST.getlist('check_box_value')
            torzsazon = request.POST.get('torzsazon')
            fajta = request.POST.get('fajta')
            himivar = request.POST.get('himivar')
            noivar = request.POST.get('noivar')

            todays_date = date.today()
        
            kezdoido = str(todays_date.year) + "." +str(todays_date.month) + "." +str(todays_date.day)

            uj_indulo = 0
            for i in osszevon_torzsazonList:
                naplo = Olnaplo.objects.get(torzsazon = i, tulajdonos = request.session.get('username'))
                uj_indulo += naplo.aktletszam

            if uj_indulo != (int(himivar) + int(noivar)):
                letszam_check_bool = False
                context = {
                    'torzsazonList' : request.session.get('torzsazonList'),
                    'osszevon_torzsazonList' : osszevon_torzsazonList,
                    'letszam_check_bool' : letszam_check_bool
                }
                return render(request, 'osszevonas.html', context)

            for i in osszevon_torzsazonList:
                for f in frissNaplok:
                    if f.torzsazon == int(i) and request.session.get('username') == f.tulajdonos:
                        f.delete()
            
            for i in osszevon_torzsazonList:
                for o in olnaplok:
                    if o.torzsazon == int(i) and request.session.get('username') == o.tulajdonos:
                        o.delete()
            

            naplo = Olnaplo(torzsazon = torzsazon, fajta = fajta, induloszam = uj_indulo, himivar = himivar, noivar = noivar, tulajdonos = request.session.get('username'), kezdet = kezdoido, aktletszam = uj_indulo, osszevont = True)

            naplo.save()
            return redirect('Fooldal')
    
    context = {
                    'torzsazonList' : request.session.get('torzsazonList'),
                    'osszevon_torzsazonList' : osszevon_torzsazonList,
                    'letszam_check_bool' : letszam_check_bool
                }
    return render(request, 'osszevonas.html', context)
    
