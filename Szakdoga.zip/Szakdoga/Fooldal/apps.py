from django.apps import AppConfig


class FooldalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Fooldal'
