from email.policy import default
from pyexpat import model
from django.db import models

# Create your models here.

class Olnaplo(models.Model):

    torzsazon = models.IntegerField()
    fajta = models.CharField(max_length=100)
    induloszam = models.IntegerField()
    himivar = models.IntegerField(default = 0)
    noivar = models.IntegerField(default = 0)
    kezdet = models.CharField(max_length=30)
    tulajdonos = models.CharField(max_length=100)
    aktletszam = models.IntegerField()
    osszevont = models.BooleanField(default = False)


class FrissNaplo(models.Model):

    nap = models.IntegerField()
    elhullas = models.IntegerField()
    him_elhullas = models.IntegerField(default = 0)
    no_elhullas = models.IntegerField(default = 0)
    tojas = models.IntegerField()
    takarmany = models.CharField(max_length=100)
    mozgas = models.CharField(max_length=100)
    egyeb = models.TextField()
    torzsazon = models.IntegerField(default=None)
    tulajdonos = models.CharField(max_length=100, default=None)