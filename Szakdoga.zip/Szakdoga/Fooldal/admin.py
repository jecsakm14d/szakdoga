from django.contrib import admin
from . models import Olnaplo, FrissNaplo

# Register your models here.
admin.site.register(Olnaplo)
admin.site.register(FrissNaplo)