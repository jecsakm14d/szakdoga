
from django.contrib import admin
from django.urls import path, include

import Fooldal

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('Bejelentkezes.urls')),
    path('index/', include('Fooldal.urls'))
]
