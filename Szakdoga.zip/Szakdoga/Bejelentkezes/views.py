import email
from http.client import HTTPResponse
from multiprocessing import context
from urllib import request
from django.shortcuts import render, redirect
import re
from Bejelentkezes.models import Felhasznalo
from . models import Felhasznalo
from django.http import HttpResponse

regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'

def check(email):
 
    if(re.fullmatch(regex, email)):
        return True
    else:
        return False

# Create your views here.

def login(request):

    if request.method == "GET":
        return render(request, 'login.html')
    elif request.method == "POST":

        if 'regisztracio' in request.POST:
            return redirect('Regisztracio')

        email = request.POST['emailLog']
        request.session['emailLog'] = email
        jelszo = request.POST.get('jelszoLog')

        felhasznalok2 = Felhasznalo.objects.all()

        bad_login = True
        for felhasznalo in felhasznalok2:
            if felhasznalo.email == email and felhasznalo.jelszo == jelszo:
                request.session['username'] = felhasznalo.felhnev
                return redirect('Fooldal')
            else:
                bad_login = False
        context={
            'bad_login' : bad_login,
            'success_register' : request.session.get('success_register')
        }

        return render(request, 'login.html', context)
        
def register(request):

    if request.method == "GET":
        return render(request, 'register.html')
    elif request.method == "POST":
        felhnev = request.POST.get('felhnev')
        email = request.POST.get('email')
        jelszo1 = request.POST.get('jelszo')
        jelszo2 = request.POST.get('jelszoujra')

        register_email_helper = True
        register_emailvalidator_helper = True
        register_jelszo_helper = True
        register_felhasznalonev_helper = True
        if Felhasznalo.objects.filter(email = email).count() != 0:
            print("email már létezik")
            register_email_helper = False
            return render(request, 'register.html', {'register_email_helper' : register_email_helper})

        if not check(email):
            print("rossz email")
            register_emailvalidator_helper = False
            return render(request, 'register.html', {'register_emailvalidator_helper' : register_emailvalidator_helper})
        
        if jelszo1 != jelszo2:
            print("nem egyezik a jelszo")
            register_jelszo_helper = False
            return render(request, 'register.html', {'register_jelszo_helper': register_jelszo_helper})
        
        user = Felhasznalo.objects.filter(felhnev=felhnev)
        
        if user.count() != 0:
            print("felhnev létezik")
            register_felhasznalonev_helper = False
            return render(request, 'register.html', {'register_felhasznalonev_helper' : register_felhasznalonev_helper})
        

        felhasznalo = Felhasznalo(felhnev = felhnev, email = email, jelszo = jelszo1)
        felhasznalo.save()

        return redirect('Bejelentkezes')